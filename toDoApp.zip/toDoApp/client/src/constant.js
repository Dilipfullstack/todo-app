const variables = {
    apiLink: "http://localhost:8080"
}

export default variables;