// import logo from './logo.svg';
import './App.css';
import Login from './component/login';
import SignUp from './component/signUp';

function App() {
  return (
    <div className="App">
      <SignUp />
    </div>
  );
}

export default App;
