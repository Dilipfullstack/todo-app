import { useState } from "react";
import axios from 'axios'
import variables from "../constant";

const SignUp = () => {

    const [newUser, setNewUser] = useState({ email: "", password: "", confirmPassword: "" })

    const handleSignup = () => {
        if (newUser.password === newUser.P && newUser.password.length > 0 && newUser.email.length>0) {
            axios({
                url: `${variables.apiLink}/signup`,
                method: "POST",
                headers: {

                },
                data: newUser,
               
            }).then((res) => {
                console.log(res)
            

                alert(res.data)
                // navigate("/")
                
            }).catch((err) => {
                
                alert(err.response.data)
                console.log(err)
            })
        } else {
            if (newUser.email.length === 0) {
                alert("email cannot be empty");
            } else if (newUser.password.length === 0) {
                alert("password cannot be empty")
            } 
            else{
                alert("password and confirm password should be same")
            }
        }
    }

    return (
        <>
        <form>
        <input type="email" required placeholder="Email ID" 
            onChange={(e) => { setNewUser({ ...newUser, email: e.target.value }) }} />
        <input type="password" required placeholder="Password" 
            onChange={(e) => { setNewUser({ ...newUser, password: e.target.value }) }} />
        <input type="password" required placeholder="Re Enter Password" 
            onChange={(e) => { setNewUser({ ...newUser, P: e.target.value }) }} />
        </form>
        <button type='submit' onClick={handleSignup}>Sign Up</button>
        </>
    )   
};

export default SignUp;