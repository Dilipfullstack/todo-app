import axios from 'axios';
import { useState } from 'react';
// import { useNavigate } from 'react-router-dom'
import variables  from '../constant';

const Login = () => {
    const [user, setUser] = useState({email: "", password: ""});
    // let navigate = useNavigate();

    const handleLogin = () => {
        if(user.email.length) {
        axios({
           url: `${variables.apiLink}/login`,
            method: "POST",
            headers: {
            },
            data: user
        }).then((data) => {       
            console.log(data)
            if(data.data.authToken.length > 0){
                localStorage.setItem("authorization", data.data.authToken);
                localStorage.setItem('userid', user.email)
                alert(`${user.email} signed in sucessfully`)
                // navigate("/listproperty")
            }
        }).catch((err) => {
            alert(err.response.data)
            if(err.response.data === "User does not exists. Please signup!"){
                // navigate("/signup")
            }
        
        })

    } else{
        alert("email cannot be empty")
    }

}

    return(
        <>
        <form>
            <input type='text' placeholder='email' name='email' id='email' 
                onChange={(e) => {setUser({...user, email: e.target.value})}} />
            <input type='text' placeholder='password' name='password' id='password' 
                onChange={(e) => {setUser({...user, password: e.target.value})}} />
        </form>
            <button type='submit' onClick={handleLogin}>Login</button>
        </>
    )
}

export default Login;